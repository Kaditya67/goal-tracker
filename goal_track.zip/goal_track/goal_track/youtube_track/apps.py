from django.apps import AppConfig


class YoutubeTrackConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'youtube_track'
